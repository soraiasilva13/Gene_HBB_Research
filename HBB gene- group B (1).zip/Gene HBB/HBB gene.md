# <span style="background-color:red;"> HBB gene
## Hemoglobin subunit beta
![alt text](image.png)


[link aqui](www.) #rencaminhar para o link no github#

###### The HBB (Hemoglobin Subunit Beta) gene is crucial for producing beta-globin, a component of hemoglobin that is essential for oxygen transport in the blood. Mutations in this gene can lead to significant genetic disorders, including sickle cell disease and beta-thalassemia, affecting millions of people worldwide. Understanding the function and genetic variations of the HBB gene is vital for diagnosing and treating these hematologic conditions.


###### Taking into consideration the analysis of different genes, it was verified that the HBB gene had an accessible understanding of its sequences as this information was quickly processed by the various software tools proposed. On the other hand, the clinical and biomedical importance associated to this gene and the study of its mutations (such as the occurrence of sickle cell anemia, which has a high incidence rate in several individuals) were also crucial factors in choosing this gene for us to study. 


## Characterization of the respective gene and protein using different databases
 The HBB gene is present in sickle cell anemia. Located in the 11th chromossome, it contains instructions for the production of beta hemoglobine. In individuals with sickle cell anemia, there is a mutation in this gene that results in the production of an abnormal form of hemoglobin (Hemoglobin S). This causes the red blood cells to take on a sickle or crescent moon shape when deoxygenated, causing obstruction in the blood vessels, severe pain, chronic anemia and other health complications.
 
> To characterize de HBB gene and the respective biologic sequences were explored the NCBI and Uniprot databases. 

> The NCBI database has comprehensive coverage (it offers access to a vast array of biological data- nucleotide sequences, protein sequences, gene expression and genetic variation), including sequences, structures, genomes and literature.
It is a trusted source with rigorous data curation and reliable information for many scientific investigations. Its developed interface facilitates data analysis, visualization and interpretation of various bioinformatics tools and software.

> The Uniprot database has an extensive coverage of protein sequences, annotations and functional information across all domains of life, high-quality data (undergoes rigorous curation processes including experimental studies, computational predictions and community submissions).It has a developed but easy interface with intuitive search functionalities (quick and relevant information about proteins, genes and biological entities). The integration with other databases allows the access to complementary data and methods and regular updates in the field of molecular biology and bioinformatics.

#### Some especific details about the HBB gene (*Homo sapiens*):
> <u>Human gene ID</u>: 3043     
> <u> Brief description of the gene summary (Pubmed) </u> - 'Mutant beta globin causes sickle cell anemia. Absence of beta chain causes beta-zero-thalassemia. Reduced amounts of detectable beta globin causes beta-plus-thalassemia. The HBB gene has higher expression on the bone marrow.'   
> <u> Chromosomal location </u> : 11p15.4   
> <u> Number of exons </u>: 3   
> <u> Some other species with the same gene </u>: Rattus norvegius (Norway rat), Bos taurus (Cow), Ovis aries (Sheep)     
> <u>Orthologs</u>:
>Taking into consideration that orthologs are genes in different species that evolved from a common ancestral gene through speciation and typically retain the same function, here are some examples of orthologs to the human HBB gene:
>1.Chimpanzee (Pan troglodytes) - HBB   
>2.Mouse (Mus musculus) - Hbb-b1    
>3.Rat (Rattus norvegicus) - Hbb    
>4.Dog (Canis lupus familiaris) - HBB    
>5.Cow (Bos taurus) - HBB     
>6.Chicken (Gallus gallus) - HBB    
>7.Zebrafish (Danio rerio) - hbbe1.1, hbbe1.2 (multiple hemoglobin beta genes)     
>8.Frog (Xenopus laevis) - hbb2

These orthologs reflect the evolutionary conservation of the beta-globin gene across different vertebrates. The genes perform the same or very similar functions in their respective organisms, primarily related to oxygen transport in the blood  

> Using the RefSeq Sequences section of the NCBI page, we verified that the gene has only one transcript with the following sequence:
ACATTTGCTTCTGACACAACTGTGTTCACTAGCAACCTCAAACAGACACCATGGTGCATC
TGACTCCTGAGGAGAAGTCTGCCGTTACTGCCCTGTGGGGCAAGGTGAACGTGGATGAAG
TTGGTGGTGAGGCCCTGGGCAGGCTGCTGGTGGTCTACCCTTGGACCCAGAGGTTCTTTG AGTCCTTTGGGGATCTGTCCACTCCTGATGCTGTTATGGGCAACCCTAAGGTGAAGGCTC
ATGGCAAGAAAGTGCTCGGTGCCTTTAGTGATGGCCTGGCTCACCTGGACAACCTCAAGG
GCACCTTTGCCACACTGAGTGAGCTGCACTGTGACAAGCTGCACGTGGATCCTGAGAACT
TCAGGCTCCTGGGCAACGTGCTGGTCTGTGTGCTGGCCCATCACTTTGGCAAAGAATTCA
CCCCACCAGTGCAGGCTGCCTATCAGAAAGTGGTGGCTGGTGTGGCTAATGCCCTGGCCC
ACAAGTATCACTAAGCTCGCTTTCTTGCTGTCCAATTTCTATTAAAGGTTCCTTTGTTCC
CTAAGTCCAACTACTAAACTGGGGGATATTATGAAGGGCCTTGAGCATCTGGATTCTGCC   
>(gene sequence- filtered DNA using Fasta Format)
### Information about the protein:
###### Hemoglobin subunit beta, encoded by Hbb gene, plays a critical role in oxygen transport and is essential for the proper functioning of red blood cells
> Hemoglobin subunit beta in *Homo sapiens* organism :  
> <u> Function</u>: The protein is responsible for carrying oxygen from the lungs to the tissues and organs of the body and for transporting carbon dioxide from the tissues back to the lungs. In the hemoglobin molecule, two alpha-globin chains and two beta-globin chains come together to form a tetramer.  
> <u> Tissue Expression</u> : This protein is primarily expressed in erythroid cells and constitutes approximately 97% of the total hemoglobin content.   
> <u> Genetic disorders </u>:
The main genetic disorders caused by the mutations in the HBB gene are sickle cell disease and beta-thalassemia.    
Sickle cell disease is caused by a single nucleotide substitution in the HBB gene, resulting in the production of abnormal hemoglobin. Beta-thalassemia encompasses a group of inherited blood disorders characterized by reduced or absent synthesis of beta-globin chains, leading to anemia and other complications.    
><u> Length</u>(in amino-acids):147      
><u> Molecular function</u>: hypotensive agent, vasoactive    
> <u>Biological process</u>: oxygen transport, transport                              

> Mvhltpeeksavtalwgkvnvdevggealgrllvvypwtqrffesfgdlstpdavmgnpk
vkahgkkvlgafsdglahldnlkgtfatlselhcdklhvdpenfrllgnvlvcvlahhfg
keftppvqaayqkvvagvanalahkyh
>(protein sequence- filtered amino-acids sequence using Fasta format)
> ![protein_structure](protein_structure.jpg) 

### Homologous proteins sequences
###### Homologous proteins are proteins that share a common evolutionary ancestry, that is, they derive from a common ancestor. It is possible to verify that they perform similar functions in different organisms. 
###### Taking in consideration the HBB gene, there are the following homologous proteins sequences:
>1. hemoglobin subunit beta [Gorilla gorilla gorilla]:
>XP_018891709.1 hemoglobin subunit beta [Gorilla gorilla gorilla]
MVHLTPEEKSAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMGNPKVKAHGKKVLGAFSDGLAHLDNLKGTFATLSELHCDKLHVDPENFKLLGNVLVCVLAHHFGKEFTPPVQAAYQKVVAGVANALAHKYH
>2. hemoglobin subunit beta [Erythrocebus patas]:
>AYO89363.1 hemoglobin subunit beta [Erythrocebus patas]
MVHLTPEEKTAVTTLWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSSPDAVMGNPKVKAHGKKVLGAFSDGLTHLDNLKGTFAQLSELHCDKLHVDPENFKLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>3. hemoglobin subunit beta [Chlorocebus sabaeus]:
>NP_001316847.1 hemoglobin subunit beta [Chlorocebus sabaeus]
MVHLTPEEKTAVTTLWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSSPDAVMGNPKVKAHGKKVLGAFSDGLAHLDNLKGTFAQLSELHCDKLHVDPENFKLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>4. hemoglobin subunit beta [Miopithecus talapoin]:
>AYO89367.1 hemoglobin subunit beta [Miopithecus talapoin]
MVHLTPEEKNAVTTLWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSSPDAVMGNPKVKAHGKKVLGAFSDGLTHLDNLKGTFAQLSELHCDKLHVDPENFKLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
NLKGTFAQLSELHCDKLHVDPENFRLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>5. hemoglobin subunit beta [Nomascus leucogenys]:
>XP_004090697.3 hemoglobin subunit beta [Nomascus leucogenys]
MVHLTPEEKSAVTALWGKVKVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMGNPKVKAHGKKVLGAFSDGLAHLDNLKGTFAQLSELHCDKLHVDPENFRLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>6. hemoglobin subunit beta [Pongo abelii]:
>XP_002822173.1 hemoglobin subunit beta [Pongo abelii]:
MVHLTPEEKSAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMGNPKVKAHGKKVLGAFSDGLAHLDNLKGTFAKLSELHCDKLHVDPENFRLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>7. hemoglobin subunit beta [Rhinopithecus roxellana]:
>XP_010361646.1 hemoglobin subunit beta [Rhinopithecus roxellana]
MVHLTPDEKAAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSSPDAVMGNAKVKAHGKKVLGAFSDGLAHLDNLKGTFAQLSELHCDKLHVDPENFRLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>8. hemoglobin subunit beta [Trachypithecus francoisi]:
>XP_033062959.1 hemoglobin subunit beta [Trachypithecus francoisi]
MVHLTPEEKAAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSSPDAVMGNPKVKAHGKKVLGAFSDGLAHLDNLKGTFAQLSELHCDKLHVDPENFRLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>9. hemoglobin subunit beta [Cercocebus atys]:
>NP_001292888.1 hemoglobin subunit beta [Cercocebus atys]
MVHLTPEEKNAVTTLWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSSPDAVMGNPKVKAHGKKVLGAFSDGLNHLDNLKGTFAQLSELHCDKLHVDPENFKLLGNVLVCVLAHHFGKEFTPQVQAAYQKVVAGVANALAHKYH
>10. hemoglobin subunit beta [Callithrix jacchus]:
>XP_002754937.1 hemoglobin subunit beta [Callithrix jacchus]
MVHLTGEEKSAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMNNPKVKAHGKKVLGAFSDGLTHLDNLKGTFAHLSELHCDKLHVDPENFRLLGNVLVCVLAHHFGKEFTPVVQAAYQKVVAGVANALAHKYH


## Multiple sequence alignment (MSA)
#### Alignment without colors:
![alinhamento_sem_cores](alinhamento_sem_cores.jpg)
#### Alignment with colors:
![alinhamento_com_cores](alinhamento_com_cores.jpg)
 All sequences have the same size, which means that may have occured a substitution or a deletion and then an addition at the same location.  
 Despite the great homogeneity, from aminoacid 60 onwards the sequences are all extremely similar.

 > Comparison between the MSA of Homo Sapiens and Gorilla Gorilla Gorilla:
 ![comparison_MSA](comparison_MSA.jpg)
 Identity: 99.32%    
Similarity: 100.00%   
Gaps: 0.00    
 Both sequences have 147 aminoacids
Analysing in detail the sequences, it is visible that a single mutation occured at position 105, which corresponds to a change from arginine to lysin.



>![logo](logo.jpg)   

## Phylogenetic tree
“Phylogenetics studies help to classify new species and provide rigorous support for the definition of taxonomic categories.”     
MSA can be used to start phylogenetic analysis. The phylogenetic tree describes the distance between the sequences under analysis. From the alignment, each column shows if there are conservation of the residues (amino-acids), mutations or divergence from common ancestor.         
>![phylo_Tree](phylo_Tree.png)       

> Phylogram using Clustal Omega
![phylogram_Clustal](phylogram_clustal.png)

> Phylogram using iTOL
![phylogenetic_tree](phylogenetic_tree.png)

Regarding the HBB gene in Homo Sapiens , its sequence is the closest to the common ancestor.  So, according with the ITOL phylogram , the distance between the Homo Sapiens  and the common ancestor is 0,00977.
The size of the tree branches represents the distance between the sequences. Thus,  the longer a branch is, the greater the distance to the common ancestor will be.
Then, with the phylogenetic threes is possible to determine the distance of the gene in different species to its common ancestor.


## Motifs
Motifs are short, recurring patterns in DNA, RNA or protein sequences that have a biological significance. These patterns can represent binding sites for proteins, such as transcription factors in DNA, or functionally important regions in proteins, such as active sites in enzymes. Identifying and analyzing motifs helps in understanding molecular functions, regulatory mechanisms, and evolutionary relationships within and across species. 

> ![motifs_1](motifs_1.jpg) 

> ![motifs_2](motifs_2.jpg)



## Functional domains
> Domains are functional regions that can be found in a sequence and are preserved better than other regions throughout evolution. Proteins can contain one or more domains and their combination is what makes their diversity in nature possible. Domain identification can give more indications about a protein's structure and how it operates.
![functional_domains](functional_domains.jpg)
> The human HBB gene has a conserved globin domain in it, which indicates that its function may be tied with oxygen transportation.








 


## Bibliographic search:
##### https://www.youtube.com/watch?v=y5UaloYTxCk 
##### https://www.ncbi.nlm.nih.gov/search/all/?term=HBB 
##### https://www.uniprot.org/uniprotkb?query=HBB
##### https://itol.embl.de/ 
##### https://www.ebi.ac.uk/ 
##### https://en.vectorbuilder.com/tool/sequence-alignment/d3fb58e3-5aa0-4df3-9945-61c9dddb6ef3.html
##### https://itol.embl.de/upload.cgi
##### https://www.genome.jp/tools-bin/search_motif_lib
##### https://www.ncbi.nlm.nih.gov/Structure/cdd/wrpsb.cgi 

















### Pesquisa realizada por: Cristiana Silva, Filipa Ferreira, Filipa Marinha
##### Laboratórios de Bioinformática
##### Licenciatura em Bioinformática , FCUP